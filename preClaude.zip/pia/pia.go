package pia

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"github.com/benburkert/dns"
	"github.com/pkg/errors"
)

type PIAWgClient interface {
	GetToken() (string, error)
	AddKey(token, publickey string) (AddKeyResult, error)
	LogLine(enabled bool, msg string)
	getMetadataServerForRegion() Server
}

type Region string
type ServerList map[Region][]Server

type PIAClient struct {
	region           string
	wireguardServers ServerList
	metadataServers  ServerList
	username         string
	password         string
	curlPath         string
	verbose          bool
	disableCache     bool
	portForwarding   bool
	caCert           []byte
}

type PIAServerList struct {
	Regions []struct {
		ID          string `json:"id"`
		Name        string `json:"name"`
		Country     string `json:"country"`
		AutoRegion  bool   `json:"auto_region"`
		DNS         string `json:"dns"`
		PortForward bool   `json:"port_forward"`
		Geo         bool   `json:"geo"`
		Servers     struct {
			Meta []Server `json:"meta"`
			Wg   []Server `json:"wg"`
		} `json:"servers"`
	} `json:"regions"`
}

type RegionInfo struct {
	ID          string `json:"id"`
	Name        string `json:"name"`
	Country     string `json:"country"`
	AutoRegion  bool   `json:"auto_region"`
	PortForward bool   `json:"port_forward"`
}

type AddKeyResult struct {
	Status     string   `json:"status"`
	ServerKey  string   `json:"server_key"`
	ServerPort int      `json:"server_port"`
	ServerIP   string   `json:"server_ip"`
	ServerVip  string   `json:"server_vip"`
	Gateway    string   `json:"gateway"`
	PeerIP     string   `json:"peer_ip"`
	PeerPubkey string   `json:"peer_pubkey"`
	DNSServers []string `json:"dns_servers"`
}

type Server struct {
	Cn string
	IP string
}

// PIA tokens are valid for ~24 hours per PIA script,
// We cache slightly less to reduce edge-case expiry flaps.
const tokenTTL = 23*time.Hour + 55*time.Minute
const piaCACertFileName = "ca.rsa.4096.crt"

// NewPIAClient
func NewPIAClient(username, password, curlPath, region string, verbose bool, portForwarding bool) (*PIAClient, error) {
	piaClient := PIAClient{
		username:       username,
		password:       password,
		curlPath:       curlPath,
		region:         region,
		verbose:        verbose,
		portForwarding: portForwarding,
	}

	// Get list of servers
	serverList, err := piaClient.getServerList()
	if err != nil {
		return nil, err
	}

	piaClient.region, err = piaClient.resolveRegionID(region, serverList)
	if err != nil {
		return nil, err
	}

	// Set servers
	piaClient.metadataServers, err = piaClient.generateMetadataServerList(serverList)
	if err != nil {
		return nil, err
	}

	piaClient.wireguardServers, err = piaClient.generateWireguardServerList(serverList)
	if err != nil {
		return nil, err
	}

	return &piaClient, nil
}

// GetToken obtains an auth token via PIA's client API.
// Primary: pure Go (hardened transport + curl-ish headers).
// Fallback: shell out to curl to mirror pia-foss/manual-connections get_token.sh.
func (p *PIAClient) GetToken() (string, error) {
	if !p.disableCache {
		token, expiresUTC, err := readCachedToken(time.Now())
		if err == nil {
			p.LogLine(p.verbose, fmt.Sprintf("Using Cached Token (expires %s)", expiresUTC.Format(time.RFC3339)))
			return token, nil
		}
	}

	// else fetchViaCurl
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	token, err := p.fetchTokenViaCurl(ctx)
	if err != nil {
		return "", errors.Wrap(err, "token request failed (curl)")
	}

	// Optionally cache the key (unencrypted...)
	if !p.disableCache {
		_ = writeCachedToken(token, tokenTTL)
	}

	return token, nil
}

// AddKey
func (p *PIAClient) AddKey(token, publickey string) (AddKeyResult, error) {
	var addKeyResp AddKeyResult

	server := p.getWireguardServerForRegion()
	host, err := piaHost(server.Cn)
	if err != nil {
		return addKeyResp, err
	}

	requestURL := fmt.Sprintf(
		"https://%v:1337/addKey?pt=%v&pubkey=%v",
		host,
		url.QueryEscape(token),
		url.QueryEscape(publickey),
	)

	if p.verbose {
		redacted := token
		if len(redacted) > 8 {
			redacted = redacted[:4] + "..." + redacted[len(redacted)-4:]
		}
		p.LogLine(true, fmt.Sprintf("AddKey Debug: host=%s ip=%s pt=%s pubkey=%s", server.Cn, server.IP, redacted, publickey))
		p.LogLine(true, fmt.Sprintf(
			"Equivalent curl: curl -s -G --connect-to '%s::%s:' --cacert %s --data-urlencode 'pt=%s' --data-urlencode 'pubkey=%s' 'https://%s:1337/addKey'",
			server.Cn, server.IP, piaCACertFileName, "<TOKEN>", publickey, server.Cn,
		))
	}

	// 1) Try native HTTP path (TLS/SNI/DNS forcing logic)
	resp, httpErr := p.executePIARequest(server, requestURL, token)
	if httpErr == nil {
		defer resp.Body.Close()
		if err := json.NewDecoder(resp.Body).Decode(&addKeyResp); err != nil {
			return addKeyResp, errors.Wrap(err, "Error Decoding Add Key Response")
		}
		return addKeyResp, nil
	}

	// 2) Fallback: mirror PIA scripts using curl --connect-to + --cacert
	ctx, cancel := context.WithTimeout(context.Background(), 25*time.Second)
	defer cancel()

	// Try system curl first (might work after future WAF changes)
	if curlBin, lookErr := exec.LookPath("curl"); lookErr == nil {
		if res, err := p.addKeyViaCurl(ctx, curlBin, server, token, publickey); err == nil {
			return res, nil
		} else {
			p.LogLine(p.verbose, fmt.Sprintf("AddKey curl (system) failed, falling back. err=%v", err))
		}
	}

	// Try OpenSSL/LibreSSL curl
	openSSLCurlPath, openSSLCurlOk, pathErr := findOpenSSLCurl(p.curlPath)
	if pathErr == nil {
		if openSSLCurlOk {
			if res, err := p.addKeyViaCurl(ctx, openSSLCurlPath, server, token, publickey); err == nil {
				return res, nil
			} else {
				// Return both errors for sanity
				return addKeyResp, fmt.Errorf("AddKey failed. http=%v openssl-curl=%v", httpErr, err)
			}
		} else {
			p.LogLine(p.verbose, "Unable")
		}

	}

	// No curl found, return the original (most useful) http error
	return addKeyResp, fmt.Errorf("AddKey failed. http=%v (curl fallback unavailable: %v)", httpErr, pathErr)
}

// addKeyViaCurl
func (p *PIAClient) addKeyViaCurl(ctx context.Context, curlBin string, server Server, token string, publicKey string) (AddKeyResult, error) {
	var out AddKeyResult

	caPath, err := p.ensureCACertOnDisk()
	if err != nil {
		return out, err
	}

	host := strings.TrimSpace(server.Cn)
	ip := strings.TrimSpace(server.IP)
	if host == "" || ip == "" {
		return out, errors.New("server CN/IP missing")
	}

	// Mirrors PIA docs/scripts (important bits: --connect-to + --cacert + -G + --data-urlencode)
	args := []string{
		"-sS", "-L",
		"-G",
		"--connect-to", fmt.Sprintf("%s::%s:", host, ip),
		"--cacert", caPath,
		"--data-urlencode", "pt=" + token,
		"--data-urlencode", "pubkey=" + publicKey,
		fmt.Sprintf("https://%s:1337/addKey", host),
	}

	if p.verbose {
		redacted := token
		if len(redacted) > 8 {
			redacted = redacted[:4] + "..." + redacted[len(redacted)-4:]
		}
		p.LogLine(true, fmt.Sprintf("AddKey Curl: bin=%s host=%s ip=%s pt=%s pubkey=%s cacert=%s",
			curlBin, host, ip, redacted, publicKey, caPath))
	}

	cmd := exec.CommandContext(ctx, curlBin, args...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	if err := cmd.Run(); err != nil {
		return out, fmt.Errorf("curl addKey failed: %w stderr=%s", err, strings.TrimSpace(stderr.String()))
	}

	raw := stdout.Bytes()
	if len(raw) == 0 {
		return out, fmt.Errorf("curl addKey returned empty body stderr=%s", strings.TrimSpace(stderr.String()))
	}

	if err := json.Unmarshal(raw, &out); err != nil {
		// Sometimes failures return HTML/text. Make it obvious.
		return out, fmt.Errorf("failed decoding curl addKey JSON: %w body=%s", err, sanitizeBody(raw))
	}

	if strings.TrimSpace(out.Status) == "" {
		return out, fmt.Errorf("curl addKey returned missing status body=%s", sanitizeBody(raw))
	}

	// PIA returns {"status":"OK"...} on success
	if strings.ToUpper(strings.TrimSpace(out.Status)) != "OK" {
		return out, fmt.Errorf("curl addKey returned status=%s body=%s", out.Status, sanitizeBody(raw))
	}

	return out, nil
}

// getWireguardServerForRegion
func (p *PIAClient) getWireguardServerForRegion() Server {
	p.LogLine(p.verbose, fmt.Sprintf("Getting WireGuard Server For Region: %s", p.region))
	val := p.wireguardServers[Region(p.region)][0]
	p.LogLine(p.verbose, fmt.Sprintf("Found WireGuard Server: %s", val))
	return val
}

func (p *PIAClient) getMetadataServerForRegion() Server {
	list := p.metadataServers[Region(p.region)]
	p.LogLine(p.verbose, fmt.Sprintf("Getting Metadata Server For Region: %s (count=%d)", p.region, len(list)))
	if len(list) == 0 {
		return Server{}
	}
	chosen := list[0]
	p.LogLine(p.verbose, fmt.Sprintf("Found Metadata Server: %+v", chosen))
	return chosen
}

// getSeverList returns a list of servers from the PIA API
func (p *PIAClient) getServerList() (PIAServerList, error) {
	var serverList PIAServerList

	resp, err := http.Get("https://serverlist.piaservers.net/vpninfo/servers/v6")
	if err != nil {
		return PIAServerList{}, err
	}

	// Strip the base64 garbage
	respBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return PIAServerList{}, err
	}
	respString := string(respBytes)
	lastBracketInd := strings.LastIndex(respString, "}")
	safeJSON := respString[:lastBracketInd+1]

	// Parse the JSON
	err = json.Unmarshal([]byte(safeJSON), &serverList)
	if err != nil {
		return PIAServerList{}, err
	}

	// Return list of servers
	return serverList, nil
}

// generateWireguardServerList
func (p *PIAClient) generateWireguardServerList(list PIAServerList) (ServerList, error) {
	servers := ServerList{}

	for _, r := range list.Regions {
		if p.portForwarding && !r.PortForward {
			continue
		}

		for _, server := range r.Servers.Wg {
			servers[Region(r.ID)] = append(servers[Region(r.ID)], Server{
				Cn: server.Cn,
				IP: server.IP,
			})
		}
	}

	if len(servers) == 0 {
		if p.portForwarding {
			return nil, errors.New("No Servers Found With Port Forwarding Enabled")
		}
		return nil, errors.New("No Servers Found")
	}

	if p.verbose {
		target := p.region
		if list, ok := servers[Region(target)]; ok {
			p.LogLine(p.verbose, fmt.Sprintf("WireGuard Servers For %s: %+v", target, list))
		} else {
			p.LogLine(p.verbose, fmt.Sprintf("No WireGuard Servers Mapped For %s", target))
		}
	}

	return servers, nil
}

// generateMetadataServerList
func (p *PIAClient) generateMetadataServerList(list PIAServerList) (ServerList, error) {
	servers := ServerList{}

	for _, r := range list.Regions {
		if p.portForwarding && !r.PortForward {
			continue
		}

		for _, server := range r.Servers.Meta {
			servers[Region(r.ID)] = append(servers[Region(r.ID)], Server{
				Cn: server.Cn,
				IP: server.IP,
			})
		}
	}

	if len(servers) == 0 {
		if p.portForwarding {
			return nil, errors.New("No Metadata Servers Found With Port Forwarding Enabled")
		}
		return nil, errors.New("No Metadata Servers Found")
	}

	if p.verbose {
		target := p.region
		if list, ok := servers[Region(target)]; ok {
			p.LogLine(p.verbose, fmt.Sprintf("Metadata Servers For %s: %+v", target, list))
		} else {
			p.LogLine(p.verbose, fmt.Sprintf("No Metadata Servers Mapped For %s", target))
		}
	}

	return servers, nil
}

// executePIARequest
func (p *PIAClient) executePIARequest(server Server, requestURL, token string) (*http.Response, error) {
	req, err := http.NewRequest("GET", requestURL, nil)
	if err != nil {
		return nil, err
	}

	// Set header to JSON
	req.Header.Set("Content-Type", "application/json")

	// Set basic auth
	if token == "" {
		req.SetBasicAuth(p.username, p.password)
	}

	// Add certificate to shared pool
	if err := p.downloadPIACertificate(); err != nil {
		return nil, errors.Wrap(err, "Error Downloading CA Certificate")
	} else {
		p.LogLine(p.verbose, "Successfully Downloaded CA Certificate")
	}

	caCertPool := x509.NewCertPool()
	caCertPool.AppendCertsFromPEM(p.caCert)

	host := strings.TrimSpace(server.Cn)
	if host == "" {
		return nil, errors.New("request URL missing hostname")
	}

	ip := strings.TrimSpace(server.IP)
	if ip == "" {
		return nil, errors.New("server IP is empty")
	}

	// Create DNS resolver for the hostname we are actually requesting
	zone := &dns.Zone{
		Origin: "",
		TTL:    5 * time.Minute,
		RRs: dns.RRSet{
			host: {
				dns.TypeA: []dns.Record{
					&dns.A{A: net.ParseIP(ip)},
				},
			},
		},
	}

	mux := new(dns.ResolveMux)
	mux.Handle(dns.TypeANY, zone.Origin, zone)

	resolver := &net.Resolver{
		PreferGo: true,
		Dial: (&dns.Client{
			Resolver: mux,
		}).Dial,
	}

	dialer := &net.Dialer{
		Resolver: resolver,
	}

	dialContext := func(ctx context.Context, network, addr string) (net.Conn, error) {
		return dialer.DialContext(ctx, network, addr)
	}

	transport := &http.Transport{
		TLSClientConfig: &tls.Config{
			RootCAs:    caCertPool,
			ServerName: server.Cn, // SNI must match the cert name (PIA uses short CNs)
		},
		DialContext: dialContext,
	}

	client := &http.Client{
		Transport: transport,
		Timeout:   20 * time.Second,
	}

	p.LogLine(p.verbose, fmt.Sprintf("PIA Request: method=%s url=%s host=%s forced_ip=%s", req.Method, req.URL.String(), host, ip))

	resp, err := client.Do(req)
	if err != nil {
		// This will include TLS failures, timeouts, etc.
		return nil, errors.Wrap(err, "PIA request failed")
	}

	body, readErr := io.ReadAll(resp.Body)
	if readErr != nil {
		_ = resp.Body.Close()
		return nil, readErr
	}
	_ = resp.Body.Close()

	// Put body back for callers that decode JSON
	resp.Body = io.NopCloser(bytes.NewReader(body))

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("Status Code %v, Response Body: %s", resp.StatusCode, string(body))
	}

	return resp, nil
}

// downloadPIACertificate
func (p *PIAClient) downloadPIACertificate() error {
	// caCert already loaded
	if len(p.caCert) > 0 {
		return nil
	}

	// Download certificate
	resp, err := http.Get("https://raw.githubusercontent.com/pia-foss/desktop/master/daemon/res/ca/rsa_4096.crt")
	if err != nil {
		return err
	}

	// Parse certificate
	p.caCert, err = io.ReadAll(resp.Body)
	if err != nil {
		return err
	}

	return nil
}

func (p *PIAClient) resolveRegionID(input string, list PIAServerList) (string, error) {
	trimmed := strings.TrimSpace(input)
	if trimmed == "" {
		return "", errors.New("Region Cannot Be Empty")
	}

	needle := strings.ToLower(trimmed)

	for _, r := range list.Regions {
		if strings.ToLower(r.ID) == needle {
			return r.ID, nil
		}
		if strings.ToLower(r.Name) == needle {
			return r.ID, nil
		}
	}

	return "", errors.New("Unknown Region: " + input)
}

func (p *PIAClient) GetAvailableRegions() ([]RegionInfo, error) {
	serverList, err := p.getServerList()
	if err != nil {
		return nil, err
	}

	regions := make([]RegionInfo, 0, len(serverList.Regions))
	for _, r := range serverList.Regions {
		regions = append(regions, RegionInfo{
			ID:          r.ID,
			Name:        r.Name,
			Country:     r.Country,
			AutoRegion:  r.AutoRegion,
			PortForward: r.PortForward,
		})
	}

	return regions, nil
}

func (p *PIAClient) LogLine(enabled bool, msg string) {
	if !enabled {
		return
	}
	fmt.Println(time.Now().Format("2006/01/02 15:04:05"), msg)
}

func atomicWriteFile(path string, data []byte, perm os.FileMode) error {
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}

	tmpFile, err := os.CreateTemp(dir, ".tmp-*")
	if err != nil {
		return err
	}

	tmpName := tmpFile.Name()
	defer func() { _ = os.Remove(tmpName) }()

	if _, err := tmpFile.Write(data); err != nil {
		_ = tmpFile.Close()
		return err
	}

	if err := tmpFile.Chmod(perm); err != nil {
		_ = tmpFile.Close()
		return err
	}

	if err := tmpFile.Close(); err != nil {
		return err
	}

	return os.Rename(tmpName, path)
}

func (p *PIAClient) ensureCACertOnDisk() (string, error) {
	if err := p.downloadPIACertificate(); err != nil {
		return "", err
	}
	if len(p.caCert) == 0 {
		return "", errors.New("PIA CA certificate is empty")
	}

	exePath, err := os.Executable()
	if err != nil {
		return "", err
	}
	exeDir := filepath.Dir(exePath)

	certPath := filepath.Join(exeDir, piaCACertFileName)

	// If it already exists, don't rewrite (avoid permission issues).
	if st, statErr := os.Stat(certPath); statErr == nil && !st.IsDir() {
		return certPath, nil
	}

	// Write it (best effort permissions)
	if writeErr := atomicWriteFile(certPath, p.caCert, 0644); writeErr != nil {
		return "", errors.Wrap(writeErr, "failed writing CA cert next to binary")
	}

	return certPath, nil
}

func findOpenSSLCurl(requested string) (string, bool, error) {
	p := strings.TrimSpace(requested)
	if p == "" {
		return "", false, errors.New("curl path is empty")
	}

	// On Windows, help users who pass "openssl_curl" without ".exe"
	if runtime.GOOS == "windows" && !strings.HasSuffix(strings.ToLower(p), ".exe") {
		p = p + ".exe"
	}

	// If it looks like a path (contains a separator) try it as-is first
	if strings.ContainsAny(p, string(os.PathSeparator)+"/\\") {
		if fileExists(p) {
			return p, true, nil
		}
		// Also try relative to cwd if they passed something like ".\\openssl_curl.exe"
		if abs, err := filepath.Abs(p); err == nil && fileExists(abs) {
			return abs, true, nil
		}
		return "", false, fmt.Errorf("curl not found at path: %s", p)
	}

	// 1) Next to the running binary
	if exe, err := os.Executable(); err == nil {
		exeDir := filepath.Dir(exe)
		candidate := filepath.Join(exeDir, p)
		if fileExists(candidate) {
			return candidate, true, nil
		}
	}

	// 2) Current working directory
	if wd, err := os.Getwd(); err == nil {
		candidate := filepath.Join(wd, p)
		if fileExists(candidate) {
			return candidate, true, nil
		}
	}

	// 3) PATH
	if lp, err := exec.LookPath(p); err == nil && fileExists(lp) {
		return lp, true, nil
	}

	return "", false, fmt.Errorf("curl binary not found: %s (searched exe dir, cwd, PATH)", p)
}

func fileExists(path string) bool {
	st, err := os.Stat(path)
	return err == nil && !st.IsDir()
}

func piaHost(cn string) (string, error) {
	cn = strings.TrimSpace(cn)
	if cn == "" {
		return "", errors.New("server CN is empty")
	}

	// If PIA ever returns a FQDN in the future, keep it.
	// But we also keep the "short" CN for TLS SNI matching.
	return cn, nil
}

func sanitizeBody(raw []byte) string {
	s := strings.TrimSpace(string(raw))
	if len(s) > 500 {
		return s[:500] + "..."
	}
	return s
}
