package pia

import (
	"bytes"
	"strings"
	"text/template"

	"github.com/pkg/errors"
	"golang.zx2c4.com/wireguard/wgctrl/wgtypes"
)

type PIAWgGenerator struct {
	pia        PIAWgClient
	verbose    bool
	serverName bool
	privatekey string
	publickey  string
	ipv6Mode   IPv6Mode
}

type PIAWgGeneratorConfig struct {
	Verbose    bool
	ServerName bool
	PrivateKey string
	PublicKey  string
	IPv6Mode   IPv6Mode
}

type templateConfig struct {
	Address             string
	AllowedIPs          string
	DNS                 string
	Endpoint            string
	EndpointPort        int
	PrivateKey          string
	PublicKey           string
	PersistentKeepalive string
	ServerCommonName    string
	PostUp              string
	PostDown            string
}

type GenerateResult struct {
	Config string
	Key    AddKeyResult
}

type IPv6Mode string

const (
	IPv6ModeAuto IPv6Mode = "auto" // Default: Add ::/0 To AllowedIPs
	IPv6ModeOff  IPv6Mode = "off"  // Only IPv4 In AllowedIPs
	IPv6ModeKill IPv6Mode = "kill" // Add wg-quick PostUp/PostDown Rules To Block IPv6
)

func NewPIAWgGenerator(pia PIAWgClient, config PIAWgGeneratorConfig) *PIAWgGenerator {
	mode := config.IPv6Mode
	if strings.TrimSpace(string(mode)) == "" {
		mode = IPv6ModeAuto
	}

	return &PIAWgGenerator{
		pia:        pia,
		verbose:    config.Verbose,
		serverName: config.ServerName,
		privatekey: config.PrivateKey,
		publickey:  config.PublicKey,
		ipv6Mode:   mode,
	}
}

// Generate - retains backwards compatibility (string only).
func (p *PIAWgGenerator) Generate() (string, error) {
	result, err := p.GenerateWithMetadata()
	if err != nil {
		return "", err
	}
	return result.Config, nil
}

// GenerateWithMetadata returns both the config and the AddKeyResult metadata (required for Port Forwarding).
func (p *PIAWgGenerator) GenerateWithMetadata() (GenerateResult, error) {
	var result GenerateResult

	p.pia.LogLine(p.verbose, "Getting PIA token")
	token, err := p.pia.GetToken()
	if err != nil {
		return result, errors.Wrap(err, "Error Getting PIA Token")
	}

	p.pia.LogLine(p.verbose, "Generating WireGuard keys")
	privatekey, publickey, err := p.generateKeys()
	if err != nil {
		return result, errors.Wrap(err, "Error Generating WireGuard Keys")
	}

	p.pia.LogLine(p.verbose, "Registering Wire Guard Public Key With PIA")
	key, err := p.pia.AddKey(token, publickey)
	if err != nil {
		return result, errors.Wrap(err, "Error Adding WireGuard Public Key To PIA Account")
	}

	p.pia.LogLine(p.verbose, "Generating WireGuard config")
	config, err := p.generateConfig(key, privatekey)
	if err != nil {
		return result, errors.Wrap(err, "Error Generating Wire Guard Config")
	}

	result.Config = config
	result.Key = key
	return result, nil
}

func (p *PIAWgGenerator) generateKeys() (string, string, error) {
	if p.privatekey != "" && p.publickey != "" {
		return p.privatekey, p.publickey, nil
	}

	// Private Key
	privateKey, err := wgtypes.GeneratePrivateKey()
	if err != nil {
		return "", "", errors.Wrap(err, "Failed To Generate Private Key")
	}
	p.pia.LogLine(p.verbose, "Private Key Generated")

	// Public Key
	publicKey := privateKey.PublicKey()
	p.pia.LogLine(p.verbose, "Public Key Generated")

	return privateKey.String(), publicKey.String(), nil
}

func (p *PIAWgGenerator) generateConfig(key AddKeyResult, privatekey string) (string, error) {
	tpl, err := template.New("config").Parse(wireguardConfigTemplate)
	if err != nil {
		return "", errors.Wrap(err, "Error Parsing WireGuard Config Template")
	}

	var serverCommonName string
	if p.serverName {
		server := p.pia.getMetadataServerForRegion()
		serverCommonName = server.Cn
	}

	endpointPort := key.ServerPort
	if endpointPort <= 0 {
		return "", errors.New("Invalid Server Port Returned By API")
	}
	if strings.TrimSpace(key.ServerIP) == "" {
		return "", errors.New("Invalid Server IP Returned By API")
	}
	if len(key.DNSServers) == 0 || strings.TrimSpace(key.DNSServers[0]) == "" {
		return "", errors.New("No DNS Servers Returned By API")
	}

	// Configure IPv6 - Default to it not leaking...
	allowedIPs := "0.0.0.0/0, ::/0"
	postUp := ""
	postDown := ""

	switch p.ipv6Mode {
	case IPv6ModeOff:
		allowedIPs = "0.0.0.0/0"
	case IPv6ModeKill:
		allowedIPs = "0.0.0.0/0, ::/0"
		// wg-quick only: kill IPv6 egress when interface is up.
		// This is intentionally strict and assumes Linux + ip6tables is available.
		postUp = "ip6tables -I OUTPUT ! -o %i -m addrtype ! --dst-type LOCAL -j DROP"
		postDown = "ip6tables -D OUTPUT ! -o %i -m addrtype ! --dst-type LOCAL -j DROP"
	case IPv6ModeAuto:
	default:
		// default -> better be safe than sorry
		allowedIPs = "0.0.0.0/0, ::/0"
	}

	tc := templateConfig{
		PrivateKey:          privatekey,
		PublicKey:           key.ServerKey,
		Endpoint:            key.ServerIP,
		EndpointPort:        endpointPort,
		DNS:                 key.DNSServers[0],
		Address:             key.PeerIP,
		AllowedIPs:          allowedIPs,
		PersistentKeepalive: "25",
		ServerCommonName:    serverCommonName,
		PostUp:              postUp,
		PostDown:            postDown,
	}

	var buf bytes.Buffer
	if err := tpl.Execute(&buf, tc); err != nil {
		return "", errors.Wrap(err, "Error Executing WireGuard Config Template")
	}

	return buf.String(), nil
}

var wireguardConfigTemplate = `[Interface]
PrivateKey = {{.PrivateKey}}
Address = {{.Address}}
DNS = {{.DNS}}
{{- if .PostUp }}
PostUp = {{.PostUp}}
{{- end }}
{{- if .PostDown }}
PostDown = {{.PostDown}}
{{- end }}
[Peer]
PublicKey = {{.PublicKey}}
AllowedIPs = {{.AllowedIPs}}
Endpoint = {{.Endpoint}}:{{.EndpointPort}}
PersistentKeepalive = {{.PersistentKeepalive}}
{{- if .ServerCommonName }}
ServerCommonName = {{.ServerCommonName}}
{{- end }}`
