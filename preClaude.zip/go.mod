module github.com/thecodingrasta/pia-wg-config-generator

go 1.24.1

require (
	github.com/benburkert/dns v0.0.0-20190225204957-d356cf78cdfc
	github.com/pkg/errors v0.9.1
	github.com/urfave/cli/v2 v2.16.3
	golang.zx2c4.com/wireguard/wgctrl v0.0.0-20220916014741-473347a5e6e3
)

require (
	github.com/cpuguy83/go-md2man/v2 v2.0.2 // indirect
	github.com/russross/blackfriday/v2 v2.1.0 // indirect
	github.com/xrash/smetrics v0.0.0-20201216005158-039620a65673 // indirect
	golang.org/x/crypto v0.46.0 // indirect
	golang.org/x/sync v0.19.0 // indirect
)
